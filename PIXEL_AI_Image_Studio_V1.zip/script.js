const $=s=>document.querySelector(s),$$=s=>document.querySelectorAll(s);
let img=null,adj={b:0,c:0,s:0};const canvas=$("#canvas"),ctx=canvas.getContext("2d");
function toast(x){let t=$("#toast");t.textContent="✓ "+x;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2000)}
function load(f){if(!f||!f.type.startsWith("image/"))return toast("Chọn một ảnh hợp lệ");let r=new FileReader();r.onload=()=>{img=new Image();img.onload=()=>{canvas.width=img.naturalWidth;canvas.height=img.naturalHeight;draw();$("#empty").style.display="none";$("#wrap").classList.add("has");$("#status").textContent=img.naturalWidth+" × "+img.naturalHeight+" px";toast("Đã tải ảnh")};img.src=r.result};r.readAsDataURL(f)}
function draw(){if(!img)return;ctx.filter=`brightness(${100+adj.b}%) contrast(${100+adj.c}%) saturate(${100+adj.s}%)`;ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0);ctx.filter="none"}
$("#upload").onclick=$("#choose").onclick=()=>$("#file").click();$("#file").onchange=e=>load(e.target.files[0]);$("#drop").ondragover=e=>e.preventDefault();$("#drop").ondrop=e=>{e.preventDefault();load(e.dataTransfer.files[0])};
$$(".tool").forEach(b=>b.onclick=()=>{let p=b.dataset.panel;$$(".tool").forEach(x=>x.classList.remove("active"));b.classList.add("active");$$(".pane").forEach(x=>x.classList.add("hide"));$("#"+p+"Pane").classList.remove("hide");$("#title").textContent=b.textContent.trim();if(innerWidth<=720)$("#menu").click()});
$("#ai").onclick=()=>document.querySelector('[data-panel="generate"]').click();$("#menu").onclick=()=>$(".side").classList.toggle("open");$("#close").onclick=()=>$(".panel").classList.remove("open");
$$("[data-a]").forEach(x=>x.oninput=()=>{adj[x.dataset.a]=+x.value;x.previousSibling.value=x.value;draw()});
$("#reset").onclick=()=>{$$("[data-a]").forEach(x=>{x.value=0;x.previousSibling.value=0});adj={b:0,c:0,s:0};draw();toast("Đã reset")};
$("#zoom").oninput=e=>{$("#zv").textContent=e.target.value+"%";canvas.style.width=e.target.value+"%"};
$("#export").onclick=()=>{if(!img)return toast("Hãy tải ảnh trước");let a=document.createElement("a");a.download="pixel-ai.png";a.href=canvas.toDataURL("image/png");a.click();toast("Đã export PNG")};
$("#new").onclick=()=>{img=null;$("#wrap").classList.remove("has");$("#empty").style.display="block";$("#status").textContent="No image loaded";$("#file").value=""};
$("#addText").onclick=()=>{if(!img)return toast("Hãy tải ảnh trước");let t=$("#text").value.trim();if(!t)return toast("Nhập nội dung trước");ctx.font=`700 ${$("#font").value}px Arial`;ctx.fillStyle="white";ctx.shadowColor="black";ctx.shadowBlur=8;ctx.fillText(t,canvas.width*.07,canvas.height*.15);ctx.shadowBlur=0;toast("Đã thêm text")};
$("#generate").onclick=()=>toast($("#prompt").value.trim()?"AI Generator sẵn sàng kết nối API ở V2":"Hãy nhập prompt trước");
$("#edit").onclick=()=>toast("AI Edit sẵn sàng kết nối API ở V2");
$$(".chip").forEach(b=>b.onclick=()=>{let group=b.parentElement;group.querySelectorAll(".chip").forEach(x=>x.classList.remove("on"));b.classList.add("on")});
